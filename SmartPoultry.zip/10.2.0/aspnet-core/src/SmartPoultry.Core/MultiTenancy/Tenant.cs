﻿using Abp.MultiTenancy;
using SmartPoultry.Authorization.Users;

namespace SmartPoultry.MultiTenancy;

public class Tenant : AbpTenant<User>
{
    public Tenant()
    {
    }

    public Tenant(string tenancyName, string name)
        : base(tenancyName, name)
    {
    }
}
