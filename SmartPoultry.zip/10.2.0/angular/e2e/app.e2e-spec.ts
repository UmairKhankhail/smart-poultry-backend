import { SmartPoultryTemplatePage } from './app.po';

describe('SmartPoultry App', function () {
    let page: SmartPoultryTemplatePage;

    beforeEach(() => {
        page = new SmartPoultryTemplatePage();
    });

    it('should display message saying app works', () => {
        page.navigateTo();
        expect(page.getParagraphText()).toEqual('app works!');
    });
});
